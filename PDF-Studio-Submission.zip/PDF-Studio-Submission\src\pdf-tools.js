import { PDFDocument, StandardFonts, rgb, degrees } from '@cantoo/pdf-lib';

export const colorFromHex = (hex) => {
  const value = hex.replace('#', '');
  return rgb(
    parseInt(value.slice(0, 2), 16) / 255,
    parseInt(value.slice(2, 4), 16) / 255,
    parseInt(value.slice(4, 6), 16) / 255,
  );
};

export async function makePdf(bytes, password) {
  return PDFDocument.load(bytes, { updateMetadata: false, ...(password ? { password } : {}) });
}

export async function savePdf(doc, options) {
  return doc.save({ useObjectStreams: true, ...options });
}

export async function encryptPdf(bytes, userPassword, ownerPassword = userPassword) {
  if (!userPassword) throw new Error('A user password is required.');
  const document = await makePdf(bytes);
  document.encrypt({ userPassword, ownerPassword });
  return savePdf(document);
}

export async function makeMergedPdf(files, password) {
  const output = await PDFDocument.create({ updateMetadata: false });
  for (const file of files) {
    const source = await makePdf(await file.arrayBuffer(), password);
    const pages = await output.copyPages(source, source.getPageIndices());
    pages.forEach((page) => output.addPage(page));
  }
  return savePdf(output);
}

export async function extractPdf(source, indices) {
  const output = await PDFDocument.create({ updateMetadata: false });
  const pages = await output.copyPages(source, indices);
  pages.forEach((page) => output.addPage(page));
  return savePdf(output);
}

export async function rasterRedact(source, pageIndex, pngBytes) {
  const output = await PDFDocument.create({ updateMetadata: false });
  const sourcePages = source.getPages();
  for (let index = 0; index < sourcePages.length; index += 1) {
    if (index !== pageIndex) {
      const [copy] = await output.copyPages(source, [index]);
      output.addPage(copy);
      continue;
    }
    const { width, height } = sourcePages[index].getSize();
    const page = output.addPage([width, height]);
    const image = await output.embedPng(pngBytes);
    page.drawImage(image, { x: 0, y: 0, width, height });
  }
  return savePdf(output);
}

export async function addText(source, pageIndex, text, { x, y, size, color, opacity = 1, rotation = 0 }) {
  const font = await source.embedFont(StandardFonts.Helvetica);
  source.getPage(pageIndex).drawText(text, {
    x, y, size, font, color: colorFromHex(color), opacity, rotate: degrees(rotation),
  });
  return savePdf(source);
}

export async function addImage(source, pageIndex, imageBytes, type, box) {
  const image = type === 'image/png'
    ? await source.embedPng(imageBytes)
    : await source.embedJpg(imageBytes);
  source.getPage(pageIndex).drawImage(image, box);
  return savePdf(source);
}

export function parsePageRanges(value, pageCount) {
  const pages = new Set();
  for (const segment of value.split(',').map((part) => part.trim()).filter(Boolean)) {
    const match = segment.match(/^(\d+)(?:\s*-\s*(\d+))?$/);
    if (!match) throw new Error(`Invalid page range: ${segment}`);
    const start = Number(match[1]);
    const end = Number(match[2] ?? match[1]);
    if (start < 1 || end < start || end > pageCount) {
      throw new Error(`Page range "${segment}" is outside 1–${pageCount}.`);
    }
    for (let page = start; page <= end; page += 1) pages.add(page - 1);
  }
  if (!pages.size) throw new Error('Enter at least one page number.');
  return [...pages].sort((a, b) => a - b);
}

export function parsePageOrder(value, pageCount) {
  const order = value.split(',').map((part) => Number(part.trim()));
  if (order.length !== pageCount || order.some((page) => !Number.isInteger(page) || page < 1 || page > pageCount)) {
    throw new Error(`Enter all ${pageCount} page numbers exactly once, in the desired order.`);
  }
  if (new Set(order).size !== pageCount) throw new Error('Each page must appear exactly once.');
  return order.map((page) => page - 1);
}

export function clearStandardMetadata(document) {
  document.setTitle('');
  document.setAuthor('');
  document.setSubject('');
  document.setKeywords([]);
  document.setCreator('');
  document.setProducer('');
  document.setCreationDate(new Date(0));
  document.setModificationDate(new Date(0));
}
