# PDF Studio

**Your documents. Your device. Your control.**

PDF Studio is a local-first PDF workspace. It uses PDF.js and `@cantoo/pdf-lib` directly in the browser; it has no account, cloud service, upload API, analytics, or remotely hosted processing service. Once installed and built, the production assets can be served entirely from this computer.

## Run locally

Requirements: Node.js 20.19+ or 22.12+.

```powershell
npm.cmd install
npm.cmd run dev
```

Open the localhost URL printed by Vite (normally `http://127.0.0.1:5173`). To build and serve the production bundle:

```powershell
npm.cmd run build
npm.cmd run preview
```

The app does not transmit document contents. Vite is a local development server; no external API is used by the app. The UI uses system font fallbacks. PDF.js, Tesseract worker/core binaries, and English OCR data are served from local project assets.

## Features

Implemented: drag/drop/open PDF; PDF.js page preview and thumbnails; zoom/page navigation; local export; local recent-file history (names and sizes only); undo/redo; merge; split/extract; reorder (page order form and thumbnail drag/drop); rotate; delete; duplicate; insert blank page; crop; add text/image; highlight; pointer drawing; shapes; whiteout; raster-page redaction; image signatures; interactive AcroForm text/checkbox fields; text/image watermark; page numbers; header/footer; date stamp; images-to-PDF; PDF-to-PNG/JPEG; selectable-text extraction; local English OCR with downloadable text output; object-stream resave with honest size comparison; metadata edit/removal; page-by-page text comparison; password-protected export; encrypted-PDF password prompt.

## Important limitations

- Redaction rasterizes the full selected page at 144 dpi, removes that page's original objects from the newly assembled PDF, and thus sacrifices selectable text/vector quality on that page. It does not OCR the page afterward. Verify the exported PDF before sharing.
- Crop changes the PDF crop box; it does not erase off-crop page content.
- Whiteout is a visual cover, not secure redaction.
- OCR recognizes text from one rendered page at a time and downloads a text file; it does not add a searchable text layer to the PDF.
- PDF comparisons are text/page-count based and do not detect image-only or visual layout changes.
- Form support targets AcroForm text, checkbox, and simple value fields; XFA, button actions, signatures, and advanced widgets are not implemented.
- Compression uses PDF object streams and may not reduce a given file. The app reports the actual before/after sizes.
- Metadata removal clears standard information dictionary values and resets PDF date metadata; it cannot guarantee removal of identifiers embedded in XMP, page content, attachments, annotations, or signatures.
- A local web application requires this machine's local server to be running. Do not expose the server to an untrusted network.

## Test

```powershell
npm.cmd test
npm.cmd run build
```

`npm test` regenerates one-, ten-, and fifty-page PDFs, an image-only scanned PDF, an image PDF, a selectable-text PDF, an AcroForm PDF, and an encrypted PDF (test password: `studio-test`). Eleven automated tests cover range/order validation, merge/extract, page counts, image/form structure, password loading and encryption, page reorder/duplicate/rotate/crop/delete, text/image insertion, metadata, and PDF.js verification that redacted text is no longer selectable. The browser OCR path was manually run against the scanned fixture and returned `SCANNED PDF`; OCR accuracy depends on scan quality. Keep `test-fixtures/scanned-quality.png` so the fixture generator can recreate the scanned PDF.

Latest validation: `npm test` passed (11 tests); `npm run build` succeeded; `npm audit` reported zero vulnerabilities. The app was launched at `http://127.0.0.1:5173`, the scanned PDF was opened locally, OCR returned the expected text, and form fields were filled in the browser. A browser request trace saw no external HTTP(S) requests. A Wi-Fi-disabled test and independent desktop-reader test have not been performed, so offline/reader compatibility is not certified. See [TESTING_REPORT.md](./TESTING_REPORT.md); `screenshots/pdf-studio-editor.png` shows the running application.

Manual evaluation should additionally inspect actual output PDFs for each operation, especially redaction, encryption, crop behavior, form preservation, and compression. The test fixtures are synthetic and not a substitute for validating production documents.
