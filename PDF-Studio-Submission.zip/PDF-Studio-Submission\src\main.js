import * as pdfjs from 'pdfjs-dist';
import workerUrl from 'pdfjs-dist/build/pdf.worker.min.mjs?url';
import { PDFDocument, StandardFonts, rgb, degrees } from '@cantoo/pdf-lib';
import {
  addImage, addText, clearStandardMetadata, colorFromHex, encryptPdf, extractPdf, makeMergedPdf, makePdf,
  parsePageOrder, parsePageRanges, rasterRedact, savePdf,
} from './pdf-tools.js';
import './styles.css';

pdfjs.GlobalWorkerOptions.workerSrc = workerUrl;

const groups = {
  Organise: ['Merge PDFs', 'Split PDF', 'Reorder pages', 'Rotate pages', 'Delete pages', 'Duplicate pages', 'Extract pages', 'Insert blank page', 'Crop pages'],
  Edit: ['Add text', 'Add image', 'Highlight', 'Draw', 'Shapes', 'Whiteout', 'Redact', 'Sign', 'Fill forms'],
  Stamp: ['Watermark', 'Page numbers', 'Header and footer', 'Date stamp'],
  Convert: ['Images to PDF', 'PDF to images', 'PDF to text', 'OCR'],
  Finish: ['Compress PDF', 'Edit details', 'Remove details', 'Compare PDFs', 'Password protect'],
};

const state = {
  name: '', bytes: null, document: null, renderDocument: null, page: 1, zoom: 1,
  selected: new Set(), busy: false, tool: null, undo: [], redo: [], pdfPassword: '',
  pageRenderTask: null, pageRenderVersion: 0, thumbnailVersion: 0,
};
const app = document.querySelector('#app');
const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
const icon = (name) => {
  const paths = {
    Organise: '<rect x="3" y="4" width="7" height="7" rx="1"/><rect x="14" y="4" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
    Edit: '<path d="m4 16.5-.8 4.3 4.3-.8L20 7.5 16.5 4 4 16.5Z"/><path d="m14.8 5.7 3.5 3.5"/>',
    Stamp: '<path d="M12 3a3 3 0 0 0-3 3c0 1.7.7 2.4 1.3 3.3L9 14h6l-1.3-4.7C14.3 8.4 15 7.7 15 6a3 3 0 0 0-3-3Z"/><path d="M5 18h14v3H5z"/>',
    Convert: '<path d="M7 7h13l-3-3"/><path d="m20 7-3 3"/><path d="M17 17H4l3 3"/><path d="m4 17 3-3"/>',
    Finish: '<path d="m5 12 4 4L19 6"/><path d="M21 12v7H3V5h12"/>',
  };
  return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${paths[name] ?? ''}</svg>`;
};

function renderShell() {
  app.innerHTML = `
    <header class="topbar">
      <a class="brand" href="#" aria-label="PDF Studio home"><span class="brand-icon"><svg viewBox="0 0 32 32" fill="none"><path d="M8 3h11l7 7v19H8z" fill="#33c8b3"/><path d="M19 3v8h7" stroke="#10191f" stroke-width="2"/><path d="M12 17h10M12 21h10M12 25h7" stroke="#10191f" stroke-width="1.6" stroke-linecap="round"/></svg></span><span class="brand-name">PDF <b>Studio</b><small>Your documents. Your device. Your control.</small></span></a>
      <div class="top-document"><span class="status-dot"></span><span id="doc-name">No document open</span></div>
      <div class="top-actions"><button class="icon-button" id="undo" title="Undo" disabled>↶</button><button class="icon-button" id="redo" title="Redo" disabled>↷</button><button class="button subtle" id="save-btn">Save PDF</button><button class="button primary" id="export-btn">Export PDF <span>↓</span></button></div>
    </header>
    <main class="layout">
      <aside class="sidebar">
        <button class="open-file" id="open-file"><span>＋</span> Open PDF</button>
        <input id="file-input" type="file" accept="application/pdf,.pdf" hidden />
        <div class="nav-label">WORKSPACE</div>
        <nav id="navigation"></nav>
        <div class="sidebar-bottom"><div class="privacy-card"><span class="lock">⌑</span><div><b>Private by design</b><small>Files stay on this device</small></div><i class="local-dot"></i></div><button class="reset-button" id="clear-workspace">Clear workspace</button></div>
      </aside>
      <section class="workspace">
        <div class="toolbar">
          <div class="toolbar-left"><button class="button subtle compact" id="browse-btn">＋ Open file</button><span class="separator"></span><span class="page-label">Page <input id="page-input" type="number" value="1" min="1" disabled /> <span id="page-total">of —</span></span></div>
          <div class="toolbar-right"><button class="icon-button" id="zoom-out" title="Zoom out">−</button><span id="zoom-value">100%</span><button class="icon-button" id="zoom-in" title="Zoom in">＋</button><span class="separator"></span><button class="icon-button" id="toggle-thumbs" title="Toggle thumbnails">▤</button></div>
        </div>
        <div class="canvas-layout">
          <aside class="thumbnails" id="thumbnails"><div class="thumb-title">PAGES <span id="thumb-count">0</span></div><div id="thumb-list"></div></aside>
          <div class="document-area" id="drop-zone">
            <div class="welcome" id="welcome">
              <div class="welcome-art"><div class="art-page"><span></span><span></span><span></span><span></span><b>PDF</b></div><div class="art-spark">✦</div></div>
              <h1>Your documents.<br/><em>Your device. Your control.</em></h1>
              <p>A complete PDF workspace that keeps your files right here on your device.</p>
              <button class="button primary large" id="welcome-open">Open a PDF <span>↑</span></button>
              <div class="welcome-note">Drop a file anywhere in this window · No uploads, no accounts</div>
              <div class="recent-area" id="recent-area"></div>
            </div>
            <div class="page-wrap" id="page-wrap" hidden><canvas id="page-canvas"></canvas><div class="drawing-overlay" id="drawing-overlay"></div></div>
            <div class="drop-overlay" id="drop-overlay"><b>Drop PDF to open</b></div>
            <div class="busy" id="busy" hidden><div class="spinner"></div><span>Working locally…</span></div>
          </div>
        </div>
        <footer class="statusbar"><span id="status-page">No document</span><span id="doc-info">Open a PDF to get started</span><span class="privacy-status"><i></i> Processed locally</span></footer>
      </section>
      <aside class="tool-panel" id="tool-panel" hidden></aside>
    </main>
    <div class="toast" id="toast" role="status"></div>
    <input id="secondary-file" type="file" hidden />
  `;
  renderNavigation();
  bindShellEvents();
  renderRecents();
  updateHistoryButtons();
}

function renderNavigation() {
  const nav = $('#navigation');
  nav.innerHTML = Object.entries(groups).map(([group, tools]) =>
    `<div class="nav-group"><button class="group-heading">${icon(group)}<span>${group}</span><b>⌄</b></button><div class="group-tools">${tools.map((tool) => `<button class="tool-link" data-tool="${tool}">${tool}</button>`).join('')}</div></div>`,
  ).join('');
  $$('.tool-link', nav).forEach((button) => button.addEventListener('click', () => openTool(button.dataset.tool)));
  $$('.group-heading', nav).forEach((button) => button.addEventListener('click', () => button.parentElement.classList.toggle('collapsed')));
}

function bindShellEvents() {
  $('#open-file').onclick = () => $('#file-input').click();
  $('#browse-btn').onclick = () => $('#file-input').click();
  $('#welcome-open').onclick = () => $('#file-input').click();
  $('#file-input').onchange = (event) => event.target.files[0] && openFile(event.target.files[0]);
  $('#export-btn').onclick = exportCurrent;
  $('#save-btn').onclick = exportCurrent;
  $('#page-input').onchange = () => { const value = Number($('#page-input').value); if (state.renderDocument && value >= 1 && value <= state.renderDocument.numPages) { state.page = value; renderPage(); } };
  $('#zoom-in').onclick = () => changeZoom(0.1);
  $('#zoom-out').onclick = () => changeZoom(-0.1);
  $('#toggle-thumbs').onclick = () => $('#thumbnails').classList.toggle('hidden');
  $('#clear-workspace').onclick = clearWorkspace;
  $('#undo').onclick = undo;
  $('#redo').onclick = redo;
  const zone = $('#drop-zone');
  zone.ondragover = (event) => { event.preventDefault(); $('#drop-overlay').classList.add('visible'); };
  zone.ondragleave = (event) => { if (!zone.contains(event.relatedTarget)) $('#drop-overlay').classList.remove('visible'); };
  zone.ondrop = (event) => { event.preventDefault(); $('#drop-overlay').classList.remove('visible'); const file = [...event.dataTransfer.files].find((item) => item.type === 'application/pdf' || item.name.toLowerCase().endsWith('.pdf')); if (file) openFile(file); else notify('Drop a PDF file to open it.'); };
  window.addEventListener('dragover', (event) => event.preventDefault());
  $('#secondary-file').onchange = (event) => { if (event.target.files.length) runSecondaryFileTool(event.target.files[0]); };
}

function notify(message, error = false) {
  const toast = $('#toast');
  toast.textContent = message;
  toast.classList.toggle('error', error);
  toast.classList.add('show');
  clearTimeout(notify.timer);
  notify.timer = setTimeout(() => toast.classList.remove('show'), 4200);
}
function setBusy(value) { state.busy = value; $('#busy').hidden = !value; }
function setStatus(message) { $('#doc-info').textContent = message; }
function selectedPages() { return state.selected.size ? [...state.selected].sort((a, b) => a - b) : [state.page - 1]; }

async function openFile(file, password = '') {
  if (state.busy) return notify('Wait for the current PDF operation to finish.');
  if (!file || (!file.type.includes('pdf') && !file.name.toLowerCase().endsWith('.pdf'))) return notify('Choose a PDF file.', true);
  state.thumbnailVersion += 1;
  setBusy(true);
  try {
    const bytes = new Uint8Array(await file.arrayBuffer());
    const doc = await makePdf(bytes, password);
    state.name = file.name;
    state.bytes = bytes;
    state.document = doc;
    state.pdfPassword = password;
    state.page = 1;
    state.selected = new Set();
    state.undo = [];
    state.redo = [];
    await refreshViewer();
    $('#doc-name').textContent = state.name;
    $('#welcome').hidden = true;
    $('#page-wrap').hidden = false;
    $('#page-input').disabled = false;
    $('#page-input').max = doc.getPageCount();
    $('#page-total').textContent = `of ${doc.getPageCount()}`;
    $('#thumb-count').textContent = doc.getPageCount();
    $('#status-page').textContent = `${doc.getPageCount()} page${doc.getPageCount() === 1 ? '' : 's'}`;
    setStatus(`${Math.max(1, Math.round(bytes.length / 1024))} KB · PDF document`);
    addRecent(file.name, bytes.length);
    await renderThumbnails();
  } catch (error) {
    if (error?.name === 'PasswordException' || /password/i.test(error?.message ?? '')) {
      state.pendingFile = file;
      openPasswordPrompt();
    } else {
      console.error(error);
      notify(`Could not open PDF: ${error.message}`, true);
    }
  } finally { setBusy(false); }
}

function openPasswordPrompt() {
  const panel = $('#tool-panel');
  panel.hidden = false;
  panel.innerHTML = `<div class="panel-head"><div><small>LOCKED DOCUMENT</small><h2>Password required</h2></div><button class="close-panel">×</button></div><p>This PDF is encrypted. Enter its password to open it locally.</p><form id="password-form"><label>PDF password<input type="password" name="password" required autofocus /></label><button class="button primary" type="submit">Unlock PDF</button></form>`;
  $('.close-panel', panel).onclick = () => { panel.hidden = true; };
  $('#password-form', panel).onsubmit = (event) => { event.preventDefault(); openFile(state.pendingFile, new FormData(event.currentTarget).get('password')); panel.hidden = true; };
}

async function refreshViewer() {
  const bytes = await state.document.save();
  state.bytes = bytes;
  state.renderDocument = await pdfjs.getDocument({ data: bytes.slice() }).promise;
  await renderPage();
}

async function renderPage() {
  if (!state.renderDocument) return;
  const version = ++state.pageRenderVersion;
  if (state.pageRenderTask) {
    const pending = state.pageRenderTask;
    pending.cancel();
    try { await pending.promise; } catch (error) { if (error?.name !== 'RenderingCancelledException') throw error; }
    if (state.pageRenderTask === pending) state.pageRenderTask = null;
  }
  if (version !== state.pageRenderVersion) return;
  const page = await state.renderDocument.getPage(state.page);
  if (version !== state.pageRenderVersion) return;
  const viewport = page.getViewport({ scale: state.zoom });
  const canvas = $('#page-canvas');
  const context = canvas.getContext('2d');
  canvas.width = viewport.width;
  canvas.height = viewport.height;
  canvas.style.width = `${viewport.width}px`;
  canvas.style.height = `${viewport.height}px`;
  const task = page.render({ canvasContext: context, viewport });
  state.pageRenderTask = task;
  try { await task.promise; } catch (error) { if (error?.name !== 'RenderingCancelledException') throw error; }
  finally { if (state.pageRenderTask === task) state.pageRenderTask = null; }
  if (version !== state.pageRenderVersion) return;
  $('#page-input').value = state.page;
  $('#status-page').textContent = `Page ${state.page} of ${state.renderDocument.numPages}`;
  if (state.tool === 'Draw') attachDrawing();
}

async function renderThumbnails() {
  const list = $('#thumb-list');
  list.innerHTML = '';
  if (!state.renderDocument) return;
  const version = ++state.thumbnailVersion;
  for (let n = 1; n <= state.renderDocument.numPages; n += 1) {
    const page = await state.renderDocument.getPage(n);
    const viewport = page.getViewport({ scale: 0.19 });
    const canvas = document.createElement('canvas');
    canvas.width = viewport.width;
    canvas.height = viewport.height;
    await page.render({ canvasContext: canvas.getContext('2d'), viewport }).promise;
    if (version !== state.thumbnailVersion) return;
    const button = document.createElement('button');
    button.className = `thumb ${state.page === n ? 'active' : ''} ${state.selected.has(n - 1) ? 'selected' : ''}`;
    button.title = `Page ${n} (click to select)`;
    button.draggable = true;
    button.dataset.page = n;
    button.append(canvas, Object.assign(document.createElement('span'), { textContent: String(n) }));
    button.onclick = (event) => {
      if (event.ctrlKey || event.metaKey || event.shiftKey) {
        if (state.selected.has(n - 1)) state.selected.delete(n - 1); else state.selected.add(n - 1);
      } else {
        state.selected = new Set([n - 1]);
        state.page = n;
      }
      renderThumbnails();
      renderPage();
    };
    button.ondragstart = (event) => { event.dataTransfer.setData('text/plain', String(n)); };
    button.ondragover = (event) => event.preventDefault();
    button.ondrop = async (event) => {
      event.preventDefault();
      const from = Number(event.dataTransfer.getData('text/plain'));
      if (from && from !== n) await reorderWithDrag(from - 1, n - 1);
    };
    list.append(button);
  }
}

async function reorderWithDrag(from, to) {
  const pageCount = state.document.getPageCount();
  const order = [...Array(pageCount).keys()];
  const [moved] = order.splice(from, 1);
  order.splice(to, 0, moved);
  await applyMutation(async (doc) => {
    const reordered = await PDFDocument.create();
    const pages = await reordered.copyPages(doc, order);
    pages.forEach((page) => reordered.addPage(page));
    return reordered;
  });
}

function changeZoom(delta) {
  state.zoom = Math.max(0.3, Math.min(2.5, state.zoom + delta));
  $('#zoom-value').textContent = `${Math.round(state.zoom * 100)}%`;
  renderPage();
}

function recordUndo() {
  state.undo.push(state.bytes.slice());
  if (state.undo.length > 10) state.undo.shift();
  state.redo = [];
  updateHistoryButtons();
}
async function applyMutation(mutator, label = 'Changes applied') {
  if (!state.document) return notify('Open a PDF first.', true);
  recordUndo();
  setBusy(true);
  try {
    const workingDocument = await makePdf(state.bytes, state.pdfPassword);
    const updated = await mutator(workingDocument);
    if (updated instanceof Uint8Array || updated instanceof ArrayBuffer) {
      state.document = await makePdf(updated);
    } else if (updated) state.document = updated;
    else state.document = workingDocument;
    state.bytes = await state.document.save();
    await refreshViewer();
    await renderThumbnails();
    $('#page-input').max = state.document.getPageCount();
    $('#page-total').textContent = `of ${state.document.getPageCount()}`;
    $('#thumb-count').textContent = state.document.getPageCount();
    setStatus(`${Math.max(1, Math.round(state.bytes.length / 1024))} KB · PDF document`);
    notify(label);
  } catch (error) {
    state.undo.pop();
    console.error(error);
    notify(error.message || 'Operation failed.', true);
  } finally { setBusy(false); }
}
function updateHistoryButtons() { $('#undo').disabled = !state.undo.length; $('#redo').disabled = !state.redo.length; }
async function undo() {
  if (!state.undo.length) return;
  state.redo.push(state.bytes.slice());
  state.document = await makePdf(state.undo.pop(), state.pdfPassword);
  await refreshViewer(); await renderThumbnails(); updateHistoryButtons();
}
async function redo() {
  if (!state.redo.length) return;
  state.undo.push(state.bytes.slice());
  state.document = await makePdf(state.redo.pop(), state.pdfPassword);
  await refreshViewer(); await renderThumbnails(); updateHistoryButtons();
}

const fields = {
  'Merge PDFs': { intro: 'Choose PDFs, then enter their file numbers in the order to merge them.', form: '<label>PDF files<input type="file" name="files" accept=".pdf,application/pdf" multiple required /></label><div id="merge-file-list" class="muted">Choose two or more files to see their numbers.</div><label>Order (comma-separated file numbers)<input name="order" placeholder="2, 1, 3" /></label><label>Output name<input name="filename" value="merged.pdf" /></label>' },
  'Split PDF': { intro: 'Create a separate PDF from a range or list of pages.', form: '<label>Pages (e.g. 1-3, 5)<input name="pages" required placeholder="1-3, 5" /></label>' },
  'Reorder pages': { intro: 'Drag page thumbnails to reorder, or enter a full page order below.', form: '<label>New order, page numbers separated by commas<input name="order" required /></label>' },
  'Rotate pages': { intro: 'Rotate the selected pages. Use Ctrl/Cmd-click to select multiple pages.', form: '<label>Direction<select name="direction"><option value="90">Clockwise 90°</option><option value="-90">Counterclockwise 90°</option><option value="180">180°</option></select></label>' },
  'Delete pages': { intro: 'Permanently remove selected pages from the exported document.', form: '<p class="selection-hint"></p><label>Page numbers (optional override)<input name="pages" placeholder="Uses selected thumbnails" /></label>' },
  'Duplicate pages': { intro: 'Insert a copy of each selected page after the original.', form: '<p class="selection-hint"></p>' },
  'Extract pages': { intro: 'Download selected pages as a new PDF.', form: '<label>Page numbers<input name="pages" placeholder="Uses selected thumbnails" /></label>' },
  'Insert blank page': { intro: 'Insert a blank page before the specified page number. Use the last option to append.', form: '<label>Insert before page<input type="number" name="position" min="1" /></label>' },
  'Crop pages': { intro: 'Crop selected pages by margins in PDF points (72 points = 1 inch).', form: '<div class="form-grid"><label>Left<input name="left" type="number" min="0" value="20" /></label><label>Right<input name="right" type="number" min="0" value="20" /></label><label>Top<input name="top" type="number" min="0" value="20" /></label><label>Bottom<input name="bottom" type="number" min="0" value="20" /></label></div>' },
  'Add text': { intro: 'Place text at a position measured from the lower-left corner in PDF points.', form: '<label>Text<input name="text" required /></label><div class="form-grid"><label>X<input name="x" type="number" value="50" /></label><label>Y<input name="y" type="number" value="100" /></label><label>Size<input name="size" type="number" value="18" min="1" /></label><label>Colour<input name="color" type="color" value="#19363c" /></label></div>' },
  'Add image': { intro: 'Place a PNG or JPEG image on the current page.', form: '<label>Image<input name="image" type="file" accept="image/png,image/jpeg" required /></label><div class="form-grid"><label>X<input name="x" type="number" value="50" /></label><label>Y<input name="y" type="number" value="100" /></label><label>Width<input name="width" type="number" value="180" /></label><label>Height<input name="height" type="number" value="90" /></label></div>' },
  'Highlight': { intro: 'Add a translucent highlight rectangle over a region of the current page.', form: '<div class="form-grid"><label>X<input name="x" type="number" value="50" /></label><label>Y<input name="y" type="number" value="400" /></label><label>Width<input name="width" type="number" value="180" /></label><label>Height<input name="height" type="number" value="24" /></label><label>Colour<input name="color" type="color" value="#ffe370" /></label></div>' },
  'Draw': { intro: 'Draw with your pointer on the page preview. Press Apply drawing to save your strokes.', form: '<label>Stroke colour<input name="color" type="color" value="#d14f4f" /></label><label>Stroke width<input name="width" type="number" value="3" min="1" max="30" /></label>' },
  'Shapes': { intro: 'Add a rectangle, circle, line or arrow at a measured position on the page.', form: '<label>Shape<select name="shape"><option>Rectangle</option><option>Circle</option><option>Line</option><option>Arrow</option></select></label><div class="form-grid"><label>X<input name="x" type="number" value="50" /></label><label>Y<input name="y" type="number" value="100" /></label><label>Width<input name="width" type="number" value="180" /></label><label>Height<input name="height" type="number" value="90" /></label></div><label>Colour<input name="color" type="color" value="#239a90" /></label>' },
  'Whiteout': { intro: 'Cover a visible region with an opaque white rectangle. Original content remains in the PDF beneath it.', form: '<div class="form-grid"><label>X<input name="x" type="number" value="50" /></label><label>Y<input name="y" type="number" value="400" /></label><label>Width<input name="width" type="number" value="180" /></label><label>Height<input name="height" type="number" value="24" /></label></div>' },
  'Redact': { intro: 'Select a region on the current page. That page will be rasterized into a new document so its original text/content is not retained.', form: '<p class="warning">Redaction removes searchability and vector quality from the redacted page. Verify the exported file before sharing.</p><div class="form-grid"><label>X %<input name="x" type="number" value="10" min="0" max="100" /></label><label>Y %<input name="y" type="number" value="35" min="0" max="100" /></label><label>Width %<input name="width" type="number" value="25" min="1" max="100" /></label><label>Height %<input name="height" type="number" value="5" min="1" max="100" /></label></div><label>Redaction colour<input name="color" type="color" value="#000000" /></label>' },
  'Sign': { intro: 'Import a signature image and place it on the current page.', form: '<label>Signature image (PNG with transparency recommended)<input name="image" type="file" accept="image/png,image/jpeg" required /></label><div class="form-grid"><label>X<input name="x" type="number" value="50" /></label><label>Y<input name="y" type="number" value="80" /></label><label>Width<input name="width" type="number" value="160" /></label><label>Height<input name="height" type="number" value="60" /></label></div>' },
  'Fill forms': { intro: 'Supported interactive form fields are listed for this PDF. Field values are saved into the document.', form: '<div id="form-fields"></div>' },
  'Watermark': { intro: 'Stamp translucent text or an image onto every page.', form: '<label>Watermark text<input name="text" value="CONFIDENTIAL" /></label><label>Watermark image (optional)<input name="image" type="file" accept="image/png,image/jpeg" /></label><div class="form-grid"><label>Text size<input name="size" type="number" value="40" /></label><label>Opacity<input name="opacity" type="number" value="0.22" step="0.05" min="0.05" max="1" /></label><label>Text colour<input name="color" type="color" value="#64767b" /></label><label>Rotation<input name="rotation" type="number" value="45" /></label></div>' },
  'Page numbers': { intro: 'Add page numbers to every page.', form: '<label>Position<select name="position"><option value="bottom-center">Bottom centre</option><option value="bottom-right">Bottom right</option><option value="bottom-left">Bottom left</option><option value="top-center">Top centre</option><option value="top-right">Top right</option></select></label><label>Format<input name="format" value="{n}" placeholder="{n} or Page {n} of {total}" /></label><label>Start at<input name="start" type="number" value="1" /></label>' },
  'Header and footer': { intro: 'Add custom header and/or footer text to every page.', form: '<label>Header text<input name="header" /></label><label>Footer text<input name="footer" /></label><label>Alignment<select name="align"><option value="center">Centre</option><option value="left">Left</option><option value="right">Right</option></select></label>' },
  'Date stamp': { intro: 'Stamp today’s date on each page.', form: '<label>Date format<select name="format"><option value="long">November 6, 2026</option><option value="iso">2026-11-06</option><option value="short">11/06/2026</option></select></label><label>Position<select name="position"><option value="bottom-right">Bottom right</option><option value="bottom-left">Bottom left</option><option value="top-right">Top right</option><option value="top-left">Top left</option></select></label>' },
  'Images to PDF': { intro: 'Create a PDF with one image per page. PNG and JPEG files are supported.', form: '<label>Images<input name="images" type="file" accept="image/png,image/jpeg" multiple required /></label><label>Output name<input name="filename" value="images.pdf" /></label>' },
  'PDF to images': { intro: 'Render each page locally and download it as PNG or JPEG.', form: '<label>Format<select name="format"><option value="png">PNG</option><option value="jpeg">JPEG</option></select></label><label>Resolution<select name="scale"><option value="1">72 dpi</option><option value="2">144 dpi</option><option value="3">216 dpi</option></select></label>' },
  'PDF to text': { intro: 'Extract selectable text in page order. Scanned pages require OCR.', form: '<div id="text-result" class="text-result">Press Extract text to begin.</div>' },
  'Compress PDF': { intro: 'Resave using compressed object streams. Original and resulting byte sizes are compared honestly.', form: '<p class="warning">PDF structure or images may prevent size reduction. The result will be reported without claiming a reduction that did not occur.</p>' },
  'Edit details': { intro: 'Edit standard PDF metadata fields.', form: '<label>Title<input name="title" /></label><label>Author<input name="author" /></label><label>Subject<input name="subject" /></label><label>Keywords<input name="keywords" /></label>' },
  'Remove details': { intro: 'Clear standard document metadata. This cannot guarantee removal of identifying content embedded in page text, images, annotations, attachments or signatures.', form: '<p class="warning">This removes standard metadata fields only; inspect the document content and attachments separately.</p>' },
  'Compare PDFs': { intro: 'Compare page counts and extracted text page-by-page.', form: '<label>Second PDF<input name="file" type="file" accept=".pdf,application/pdf" required /></label><div id="compare-result" class="text-result"></div>' },
  'Password protect': { intro: 'Encrypt the exported document with a user password. Choose a strong password and store it safely.', form: '<label>User password<input name="password" type="password" minlength="1" required /></label><label>Owner password (optional)<input name="ownerPassword" type="password" /></label>' },
  'OCR': { intro: 'Recognize text in a scanned page using locally bundled English OCR data.', form: '<label>Page number<input name="page" type="number" min="1" value="1" /></label><div class="text-result" id="ocr-result"></div>' },
};

function openTool(tool) {
  if (state.busy) return notify('Wait for the current PDF operation to finish.');
  if (!state.document && !['Merge PDFs', 'Images to PDF'].includes(tool)) return notify('Open a PDF first.', true);
  const config = fields[tool];
  state.tool = tool;
  const panel = $('#tool-panel');
  panel.hidden = false;
  panel.innerHTML = `<div class="panel-head"><div><small>${Object.keys(groups).find((key) => groups[key].includes(tool)) ?? 'TOOLS'}</small><h2>${tool}</h2></div><button class="close-panel" aria-label="Close">×</button></div><p>${config.intro}</p><form id="tool-form">${config.form}<div class="panel-actions"><button type="button" class="button subtle cancel-tool">Cancel</button><button type="submit" class="button primary" id="apply-tool">${tool === 'PDF to text' ? 'Extract text' : tool === 'Draw' ? 'Apply drawing' : tool === 'OCR' ? 'Run OCR' : 'Apply'}</button></div></form>`;
  $('.close-panel', panel).onclick = closeTool;
  $('.cancel-tool', panel).onclick = closeTool;
  $('#tool-form', panel).onsubmit = (event) => { event.preventDefault(); runTool(tool, new FormData(event.currentTarget)); };
  $$('.selection-hint', panel).forEach((element) => { element.textContent = `Selected: ${selectedPages().map((page) => page + 1).join(', ')}`; });
  if (tool === 'Reorder pages') $('input[name="order"]', panel).value = [...Array(state.document.getPageCount()).keys()].map((n) => n + 1).join(', ');
  if (tool === 'Merge PDFs') {
    $('input[name="files"]', panel).onchange = (event) => {
      $('#merge-file-list', panel).innerHTML = [...event.target.files].map((file, index) => `${index + 1}. ${escapeHtml(file.name)}`).join('<br/>') || 'Choose two or more files to see their numbers.';
      $('input[name="order"]', panel).value = [...event.target.files].map((_, index) => index + 1).join(', ');
    };
  }
  if (tool === 'Redact') {
    const regionButton = document.createElement('button');
    regionButton.type = 'button';
    regionButton.className = 'button subtle';
    regionButton.textContent = 'Select region on page';
    regionButton.onclick = selectRedactionRegion;
    $('.panel-actions', panel).before(regionButton);
  }
  if (tool === 'Insert blank page') $('input[name="position"]', panel).value = String(state.page);
  if (tool === 'Fill forms') renderFormFields();
  if (tool === 'Edit details') {
    $('input[name="title"]', panel).value = state.document.getTitle() ?? '';
    $('input[name="author"]', panel).value = state.document.getAuthor() ?? '';
    $('input[name="subject"]', panel).value = state.document.getSubject() ?? '';
    $('input[name="keywords"]', panel).value = state.document.getKeywords()?.join(', ') ?? '';
  }
  if (tool === 'Draw') attachDrawing();
  if (tool === 'OCR') $('#ocr-result').textContent = 'English OCR runs locally using bundled language data.';
}
function closeTool() { $('#tool-panel').hidden = true; state.tool = null; $('#drawing-overlay').replaceChildren(); renderPage(); }

function getNums(data) {
  const numeric = (name, fallback = 0) => Number(data.get(name) ?? fallback);
  return numeric;
}

async function runTool(tool, data) {
  const numeric = getNums(data);
  try {
    if (tool === 'Merge PDFs') {
      let files = [...data.getAll('files')].filter((file) => file.size);
      if (files.length < 2) throw new Error('Choose at least two PDF files to merge.');
      const orderValue = String(data.get('order') ?? '').trim();
      if (orderValue) {
        const order = orderValue.split(',').map((part) => Number(part.trim()));
        if (order.length !== files.length || order.some((index) => !Number.isInteger(index) || index < 1 || index > files.length) || new Set(order).size !== files.length) {
          throw new Error(`Enter each selected file number from 1 to ${files.length} exactly once.`);
        }
        files = order.map((index) => files[index - 1]);
      }
      setBusy(true);
      const bytes = await makeMergedPdf(files, state.pdfPassword);
      download(bytes, safeName(data.get('filename') || 'merged.pdf'));
      notify(`Merged ${files.length} PDFs into ${new Blob([bytes]).size} bytes.`);
      setBusy(false); closeTool(); return;
    }
    if (tool === 'Images to PDF') {
      const files = [...data.getAll('images')].filter((file) => file.size);
      if (!files.length) throw new Error('Choose at least one image.');
      const output = await PDFDocument.create({ updateMetadata: false });
      for (const file of files) {
        const bytes = await file.arrayBuffer();
        const image = file.type === 'image/png' ? await output.embedPng(bytes) : await output.embedJpg(bytes);
        const page = output.addPage([image.width, image.height]);
        page.drawImage(image, { x: 0, y: 0, width: image.width, height: image.height });
      }
      download(await output.save(), safeName(data.get('filename') || 'images.pdf'));
      notify(`Created PDF with ${files.length} page${files.length === 1 ? '' : 's'}.`); closeTool(); return;
    }
    if (tool === 'PDF to text') { await extractText(); closeTool(); return; }
    if (tool === 'PDF to images') { await exportImages(data.get('format'), numeric('scale', 1)); closeTool(); return; }
    if (tool === 'Compare PDFs') { await compareDocument(data.get('file')); return; }
    if (tool === 'OCR') { await runOcr(numeric('page', 1)); return; }
    if (tool === 'Fill forms') { await fillForms(data); closeTool(); return; }
    if (tool === 'Password protect') { await encryptDocument(data.get('password'), data.get('ownerPassword')); closeTool(); return; }
    if (tool === 'Compress PDF') {
      const before = state.bytes.byteLength;
      const compressed = await savePdf(state.document);
      const after = compressed.byteLength;
      download(compressed, outputName());
      notify(after < before ? `Compressed from ${formatBytes(before)} to ${formatBytes(after)}.` : `No size reduction: ${formatBytes(before)} → ${formatBytes(after)}.`, after >= before);
      closeTool(); return;
    }
    if (tool === 'Redact') { await runRedaction(data); closeTool(); return; }
    if (tool === 'Delete pages') {
      const indices = data.get('pages') ? parsePageRanges(data.get('pages'), state.document.getPageCount()) : selectedPages();
      if (indices.length >= state.document.getPageCount()) throw new Error('A PDF must retain at least one page.');
      if (!window.confirm(`Permanently delete ${indices.length} page(s)? This can be undone locally.`)) return;
      state.page = Math.min(state.page, state.document.getPageCount() - indices.length);
      await applyMutation((doc) => { [...indices].sort((a, b) => b - a).forEach((index) => doc.removePage(index)); return doc; }, 'Selected pages deleted');
      closeTool(); return;
    }
    if (tool === 'Split PDF' || tool === 'Extract pages') {
      const indices = tool === 'Split PDF' ? parsePageRanges(data.get('pages'), state.document.getPageCount()) : (data.get('pages') ? parsePageRanges(data.get('pages'), state.document.getPageCount()) : selectedPages());
      const bytes = await extractPdf(state.document, indices);
      download(bytes, `${fileStem(state.name)}-${tool === 'Split PDF' ? 'split' : 'extract'}.pdf`);
      notify(`Exported ${indices.length} selected page(s).`); closeTool(); return;
    }
    if (tool === 'Reorder pages') {
      const order = parsePageOrder(data.get('order'), state.document.getPageCount());
      await applyMutation(async (doc) => {
        const pages = await doc.copyPages(doc, order);
        const output = await PDFDocument.create({ updateMetadata: false });
        pages.forEach((page) => output.addPage(page));
        return output;
      }, 'Pages reordered');
      closeTool(); return;
    }
    if (tool === 'Rotate pages') {
      const rotation = Number(data.get('direction'));
      await applyMutation((doc) => { selectedPages().forEach((index) => { const page = doc.getPage(index); page.setRotation(degrees((page.getRotation().angle + rotation + 360) % 360)); }); return doc; }, 'Pages rotated');
      closeTool(); return;
    }
    if (tool === 'Duplicate pages') {
      const indices = selectedPages();
      await applyMutation(async (doc) => {
        for (const index of [...indices].sort((a, b) => b - a)) { const [copy] = await doc.copyPages(doc, [index]); doc.insertPage(index + 1, copy); }
        return doc;
      }, 'Pages duplicated');
      closeTool(); return;
    }
    if (tool === 'Insert blank page') {
      const position = numeric('position', state.page);
      const pages = state.document.getPages();
      if (position < 1 || position > pages.length + 1) throw new Error(`Choose a position from 1 to ${pages.length + 1}.`);
      const [reference] = pages;
      const { width, height } = reference.getSize();
      await applyMutation((doc) => { doc.insertPage(position - 1, [width, height]); return doc; }, 'Blank page inserted');
      closeTool(); return;
    }
    if (tool === 'Crop pages') {
      await applyMutation((doc) => {
        selectedPages().forEach((index) => {
          const page = doc.getPage(index); const { width, height } = page.getSize();
          const left = numeric('left'), right = numeric('right'), top = numeric('top'), bottom = numeric('bottom');
          if (left + right >= width || top + bottom >= height) throw new Error('Crop margins exceed the page dimensions.');
          page.setCropBox(left, bottom, width - left - right, height - top - bottom);
        });
        return doc;
      }, 'Page crop applied');
      closeTool(); return;
    }
    if (tool === 'Add text') {
      await applyMutation((doc) => addText(doc, state.page - 1, data.get('text'), { x: numeric('x'), y: numeric('y'), size: numeric('size', 18), color: data.get('color') }), 'Text added');
      closeTool(); return;
    }
    if (tool === 'Add image' || tool === 'Sign') {
      const image = data.get('image');
      if (!image?.size) throw new Error('Select a PNG or JPEG image.');
      const box = { x: numeric('x'), y: numeric('y'), width: numeric('width', 180), height: numeric('height', 90) };
      const imageBytes = new Uint8Array(await image.arrayBuffer());
      await applyMutation((doc) => addImage(doc, state.page - 1, imageBytes, image.type, box), tool === 'Sign' ? 'Signature added' : 'Image added');
      closeTool(); return;
    }
    if (tool === 'Highlight' || tool === 'Whiteout' || tool === 'Shapes') {
      await applyMutation((doc) => {
        const page = doc.getPage(state.page - 1);
        const x = numeric('x'), y = numeric('y'), width = numeric('width', 180), height = numeric('height', 24), color = colorFromHex(data.get('color') || '#ffffff');
        if (tool === 'Highlight') page.drawRectangle({ x, y, width, height, color, opacity: 0.42, borderWidth: 0 });
        else if (tool === 'Whiteout') page.drawRectangle({ x, y, width, height, color: rgb(1, 1, 1), borderWidth: 0 });
        else {
          const shape = data.get('shape');
          if (shape === 'Circle') page.drawEllipse({ x: x + width / 2, y: y + height / 2, xScale: width / 2, yScale: height / 2, borderColor: color, borderWidth: 2 });
          else if (shape === 'Line' || shape === 'Arrow') {
            page.drawLine({ start: { x, y }, end: { x: x + width, y: y + height }, color, thickness: 2 });
            if (shape === 'Arrow') {
              const angle = Math.atan2(height, width);
              for (const side of [-1, 1]) page.drawLine({ start: { x: x + width, y: y + height }, end: { x: x + width - 12 * Math.cos(angle + side * 0.5), y: y + height - 12 * Math.sin(angle + side * 0.5) }, color, thickness: 2 });
            }
          } else page.drawRectangle({ x, y, width, height, borderColor: color, borderWidth: 2 });
        }
        return doc;
      }, `${tool} added`);
      closeTool(); return;
    }
    if (tool === 'Draw') {
      const points = state.drawPoints ?? [];
      if (points.length < 2) throw new Error('Draw at least two points on the page preview.');
      await applyMutation((doc) => {
        const page = doc.getPage(state.page - 1);
        for (let i = 1; i < points.length; i += 1) page.drawLine({ start: points[i - 1], end: points[i], color: colorFromHex(data.get('color')), thickness: numeric('width', 3) });
        return doc;
      }, 'Drawing added');
      state.drawPoints = []; closeTool(); return;
    }
    if (tool === 'Watermark' || tool === 'Page numbers' || tool === 'Header and footer' || tool === 'Date stamp') {
      await applyMutation(async (doc) => {
        const font = await doc.embedFont(StandardFonts.Helvetica);
        const pages = doc.getPages();
        const watermarkFile = tool === 'Watermark' ? data.get('image') : null;
        const watermarkImage = watermarkFile?.size
          ? (watermarkFile.type === 'image/png'
            ? await doc.embedPng(new Uint8Array(await watermarkFile.arrayBuffer()))
            : await doc.embedJpg(new Uint8Array(await watermarkFile.arrayBuffer())))
          : null;
        if (tool === 'Watermark' && !watermarkImage && !data.get('text')) throw new Error('Enter watermark text or choose an image.');
        for (const [index, page] of pages.entries()) {
          const { width, height } = page.getSize();
          if (tool === 'Watermark' && watermarkImage) {
            const scaled = watermarkImage.scale(Math.min(width * 0.32 / watermarkImage.width, height * 0.2 / watermarkImage.height));
            page.drawImage(watermarkImage, { x: (width - scaled.width) / 2, y: (height - scaled.height) / 2, ...scaled, opacity: numeric('opacity', 0.22) });
          } else if (tool === 'Watermark') {
            page.drawText(data.get('text'), { x: width * 0.14, y: height * 0.48, size: numeric('size', 40), font, color: colorFromHex(data.get('color')), opacity: numeric('opacity', 0.22), rotate: degrees(numeric('rotation', 45)) });
          }
          if (tool === 'Page numbers') {
            const text = data.get('format').replaceAll('{n}', String(index + numeric('start', 1))).replaceAll('{total}', String(pages.length));
            const pos = data.get('position');
            const x = pos.endsWith('left') ? 40 : pos.endsWith('right') ? width - font.widthOfTextAtSize(text, 10) - 40 : (width - font.widthOfTextAtSize(text, 10)) / 2;
            page.drawText(text, { x, y: pos.startsWith('top') ? height - 32 : 24, size: 10, font });
          }
          if (tool === 'Header and footer') {
            const align = data.get('align');
            for (const [text, isHeader] of [[data.get('header'), true], [data.get('footer'), false]]) {
              if (!text) continue;
              const x = align === 'left' ? 36 : align === 'right' ? width - font.widthOfTextAtSize(text, 10) - 36 : (width - font.widthOfTextAtSize(text, 10)) / 2;
              page.drawText(text, { x, y: isHeader ? height - 28 : 22, size: 10, font });
            }
          }
          if (tool === 'Date stamp') {
            const format = data.get('format');
            const now = new Date();
            const date = format === 'iso' ? `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}` : format === 'short' ? new Intl.DateTimeFormat('en-US').format(now) : new Intl.DateTimeFormat('en-US', { dateStyle: 'long' }).format(now);
            const pos = data.get('position');
            const x = pos.endsWith('left') ? 36 : width - font.widthOfTextAtSize(date, 10) - 36;
            page.drawText(date, { x, y: pos.startsWith('top') ? height - 28 : 22, size: 10, font });
          }
        }
        return doc;
      }, `${tool} applied`);
      closeTool(); return;
    }
    if (tool === 'Edit details') {
      await applyMutation((doc) => {
        doc.setTitle(data.get('title')); doc.setAuthor(data.get('author')); doc.setSubject(data.get('subject'));
        doc.setKeywords(data.get('keywords').split(',').map((word) => word.trim()).filter(Boolean));
        return doc;
      }, 'Document details updated');
      closeTool(); return;
    }
    if (tool === 'Remove details') {
      if (!window.confirm('Remove standard metadata fields from this PDF?')) return;
      await applyMutation((doc) => {
        clearStandardMetadata(doc);
        return doc;
      }, 'Standard metadata removed');
      closeTool(); return;
    }
    throw new Error(`${tool} is not available.`);
  } catch (error) {
    console.error(error);
    notify(error.message || 'Operation failed.', true);
  }
}

async function runRedaction(data) {
  if (!window.confirm('Redact selected region? The page will be flattened to an image and the source page content discarded.')) return;
  const pageIndex = state.page - 1;
  const pdfPage = await state.renderDocument.getPage(state.page);
  const viewport = pdfPage.getViewport({ scale: 2 });
  const canvas = document.createElement('canvas');
  canvas.width = viewport.width; canvas.height = viewport.height;
  const context = canvas.getContext('2d');
  await pdfPage.render({ canvasContext: context, viewport }).promise;
  const { width, height } = state.document.getPage(pageIndex).getSize();
  const x = Number(data.get('x')) / 100 * canvas.width;
  const y = Number(data.get('y')) / 100 * canvas.height;
  const w = Number(data.get('width')) / 100 * canvas.width;
  const h = Number(data.get('height')) / 100 * canvas.height;
  context.fillStyle = data.get('color');
  context.fillRect(x, y, w, h);
  const blob = await new Promise((resolve) => canvas.toBlob(resolve, 'image/png'));
  const png = new Uint8Array(await blob.arrayBuffer());
  const output = await rasterRedact(state.document, pageIndex, png);
  await applyMutation(() => output, 'Redaction applied to a rasterized page');
}

function attachDrawing() {
  const canvas = $('#page-canvas');
  if (!canvas || state.tool !== 'Draw') return;
  const overlay = $('#drawing-overlay');
  overlay.style.width = canvas.style.width; overlay.style.height = canvas.style.height;
  overlay.onpointerdown = (event) => {
    overlay.setPointerCapture(event.pointerId);
    const rect = overlay.getBoundingClientRect();
    const { width, height } = state.document.getPage(state.page - 1).getSize();
    state.drawPoints = [{ x: (event.clientX - rect.left) / rect.width * width, y: height - (event.clientY - rect.top) / rect.height * height }];
    overlay.classList.add('drawing');
  };
  overlay.onpointermove = (event) => {
    if (!overlay.hasPointerCapture(event.pointerId)) return;
    const rect = overlay.getBoundingClientRect(); const { width, height } = state.document.getPage(state.page - 1).getSize();
    state.drawPoints.push({ x: (event.clientX - rect.left) / rect.width * width, y: height - (event.clientY - rect.top) / rect.height * height });
    const dot = document.createElement('i'); dot.style.left = `${event.clientX - rect.left}px`; dot.style.top = `${event.clientY - rect.top}px`; overlay.append(dot);
  };
  overlay.onpointerup = (event) => { if (overlay.hasPointerCapture(event.pointerId)) overlay.releasePointerCapture(event.pointerId); };
}

function selectRedactionRegion() {
  const canvas = $('#page-canvas');
  const overlay = $('#drawing-overlay');
  if (!canvas || !state.document) return;
  overlay.style.width = canvas.style.width;
  overlay.style.height = canvas.style.height;
  overlay.classList.add('selecting-redaction');
  overlay.replaceChildren();
  let start;
  let selection;
  overlay.onpointerdown = (event) => {
    const bounds = overlay.getBoundingClientRect();
    start = { x: event.clientX - bounds.left, y: event.clientY - bounds.top };
    overlay.setPointerCapture(event.pointerId);
    selection = document.createElement('div');
    selection.className = 'redaction-region';
    overlay.append(selection);
  };
  overlay.onpointermove = (event) => {
    if (!start || !selection) return;
    const bounds = overlay.getBoundingClientRect();
    const current = { x: event.clientX - bounds.left, y: event.clientY - bounds.top };
    selection.style.left = `${Math.min(start.x, current.x)}px`;
    selection.style.top = `${Math.min(start.y, current.y)}px`;
    selection.style.width = `${Math.abs(current.x - start.x)}px`;
    selection.style.height = `${Math.abs(current.y - start.y)}px`;
  };
  overlay.onpointerup = (event) => {
    if (!start || !selection) return;
    const bounds = overlay.getBoundingClientRect();
    const current = { x: event.clientX - bounds.left, y: event.clientY - bounds.top };
    const x = Math.min(start.x, current.x) / bounds.width * 100;
    const y = Math.min(start.y, current.y) / bounds.height * 100;
    const width = Math.abs(current.x - start.x) / bounds.width * 100;
    const height = Math.abs(current.y - start.y) / bounds.height * 100;
    for (const [name, value] of Object.entries({ x, y, width, height })) {
      $(`#tool-form [name="${name}"]`).value = value.toFixed(2);
    }
    overlay.classList.remove('selecting-redaction');
    overlay.replaceChildren();
    start = null;
    selection = null;
    if (overlay.hasPointerCapture(event.pointerId)) overlay.releasePointerCapture(event.pointerId);
  };
}

function renderFormFields() {
  const form = state.document.getForm();
  const fieldsList = form.getFields();
  const container = $('#form-fields');
  if (!fieldsList.length) { container.innerHTML = '<p class="muted">No interactive AcroForm fields found.</p>'; return; }
  container.innerHTML = fieldsList.map((field, index) => {
    const rawName = field.getName();
    const name = escapeHtml(rawName);
    if (field.constructor.name.includes('CheckBox')) return `<label class="checkbox-field"><input type="checkbox" name="form_${index}" data-field="${name}" ${field.isChecked() ? 'checked' : ''} /> ${name}</label>`;
    if (field.constructor.name.includes('Dropdown')) return `<label>${name}<input name="form_${index}" data-field="${name}" value="${escapeHtml(field.getSelected()?.[0] ?? '')}" /></label>`;
    if (field.constructor.name.includes('RadioGroup')) return `<label>${name}<input name="form_${index}" data-field="${name}" value="${escapeHtml(field.getSelected() ?? '')}" /></label>`;
    if (field.constructor.name.includes('Button')) return `<p class="muted">${name} (button field not editable)</p>`;
    return `<label>${name}<input name="form_${index}" data-field="${name}" value="${escapeHtml(field.getText?.() ?? '')}" /></label>`;
  }).join('');
}
async function fillForms(data) {
  await applyMutation((doc) => {
    const form = doc.getForm();
    for (const field of form.getFields()) {
      const name = field.getName();
      const input = $(`[data-field="${CSS.escape(name)}"]`, $('#tool-form'));
      if (!input) continue;
      if (field.constructor.name.includes('CheckBox')) input.checked ? field.check() : field.uncheck();
      else if (field.setText) field.setText(input.value);
    }
    return doc;
  }, 'Form field values saved');
}

async function extractText() {
  const parts = [];
  for (let pageNumber = 1; pageNumber <= state.renderDocument.numPages; pageNumber += 1) {
    const page = await state.renderDocument.getPage(pageNumber);
    const content = await page.getTextContent();
    parts.push(`--- Page ${pageNumber} ---\n${content.items.map((item) => item.str).join(' ')}`);
  }
  const text = parts.join('\n\n');
  download(new TextEncoder().encode(text), `${fileStem(state.name)}.txt`, 'text/plain');
  notify('Extracted text downloaded.');
}
async function exportImages(format, scale) {
  for (let pageNumber = 1; pageNumber <= state.renderDocument.numPages; pageNumber += 1) {
    const page = await state.renderDocument.getPage(pageNumber);
    const viewport = page.getViewport({ scale: Number(scale) });
    const canvas = document.createElement('canvas');
    canvas.width = viewport.width; canvas.height = viewport.height;
    await page.render({ canvasContext: canvas.getContext('2d'), viewport }).promise;
    const blob = await new Promise((resolve) => canvas.toBlob(resolve, format === 'png' ? 'image/png' : 'image/jpeg', 0.92));
    download(new Uint8Array(await blob.arrayBuffer()), `${fileStem(state.name)}-page-${pageNumber}.${format}`, blob.type);
    await new Promise((resolve) => setTimeout(resolve, 120));
  }
  notify(`Exported ${state.renderDocument.numPages} page image(s).`);
}
async function compareDocument(file) {
  if (!file?.size) throw new Error('Choose a second PDF.');
  const otherBytes = new Uint8Array(await file.arrayBuffer());
  const other = await pdfjs.getDocument({ data: otherBytes }).promise;
  const maxPages = Math.max(state.renderDocument.numPages, other.numPages);
  const lines = [`Current: ${state.renderDocument.numPages} pages · Comparison: ${other.numPages} pages`, ''];
  for (let i = 1; i <= maxPages; i += 1) {
    if (i > state.renderDocument.numPages) { lines.push(`Page ${i}: only in comparison PDF`); continue; }
    if (i > other.numPages) { lines.push(`Page ${i}: only in current PDF`); continue; }
    const [a, b] = await Promise.all([state.renderDocument.getPage(i), other.getPage(i)]);
    const [ta, tb] = await Promise.all([a.getTextContent(), b.getTextContent()]);
    const textA = ta.items.map((item) => item.str).join(' ').trim();
    const textB = tb.items.map((item) => item.str).join(' ').trim();
    if (textA !== textB) lines.push(`Page ${i}: text differs\n  Current: ${truncate(textA)}\n  Other:   ${truncate(textB)}`);
  }
  $('#compare-result').textContent = lines.length > 2 ? lines.join('\n') : `${lines[0]}\nNo text differences found. Scanned image-only differences are not detected.`;
}

async function encryptDocument(userPassword, ownerPassword) {
  const encrypted = await encryptPdf(state.bytes, userPassword, ownerPassword || userPassword);
  download(encrypted, outputName());
  notify('Password-protected PDF exported. Reopen it and verify the password before sharing.');
}
async function runSecondaryFileTool(file) {
  // The secondary picker is used only by tools that explicitly request a second document.
  if (state.tool === 'Compare PDFs') await compareDocument(file);
}
async function runOcr(pageNumber) {
  if (!state.renderDocument) throw new Error('Wait for the PDF to finish loading, then try OCR again.');
  if (!Number.isInteger(pageNumber) || pageNumber < 1 || pageNumber > state.renderDocument.numPages) {
    throw new Error(`Choose a page from 1 to ${state.renderDocument.numPages}.`);
  }
  const { createWorker } = await import('tesseract.js');
  const resultElement = $('#ocr-result');
  const applyButton = $('#apply-tool');
  applyButton.disabled = true;
  resultElement.textContent = 'Loading the offline OCR engine…';
  let worker;
  try {
    worker = await createWorker('eng', 1, {
      workerPath: '/tesseract/worker.min.js',
      corePath: '/tesseract/core',
      langPath: '/tessdata',
      gzip: true,
      logger: (progress) => {
        if (progress.status) resultElement.textContent = `${progress.status}${progress.progress ? ` (${Math.round(progress.progress * 100)}%)` : ''}`;
      },
    });
    const page = await state.renderDocument.getPage(pageNumber);
    const viewport = page.getViewport({ scale: 2 });
    const canvas = document.createElement('canvas');
    canvas.width = viewport.width;
    canvas.height = viewport.height;
    await page.render({ canvasContext: canvas.getContext('2d'), viewport }).promise;
    const { data } = await worker.recognize(canvas);
    resultElement.textContent = data.text.trim() || 'No text detected.';
    if (data.text.trim()) {
      const downloadButton = document.createElement('button');
      downloadButton.type = 'button';
      downloadButton.className = 'button subtle';
      downloadButton.textContent = 'Download OCR text';
      downloadButton.onclick = () => download(new TextEncoder().encode(data.text), `${fileStem(state.name)}-page-${pageNumber}-ocr.txt`, 'text/plain');
      resultElement.after(downloadButton);
    }
    notify('OCR completed locally.');
  } finally {
    if (worker) await worker.terminate();
    applyButton.disabled = false;
  }
}

function exportCurrent() {
  if (!state.document) return notify('Open a PDF first.', true);
  download(state.bytes, outputName());
  notify('PDF exported to your downloads.');
}
function download(bytes, name, type = 'application/pdf') {
  const url = URL.createObjectURL(new Blob([bytes], { type }));
  const link = document.createElement('a');
  link.href = url; link.download = name; link.click();
  setTimeout(() => URL.revokeObjectURL(url), 1500);
}
function outputName() { return `${fileStem(state.name || 'document')}-edited.pdf`; }
function fileStem(name) { return name.replace(/\.pdf$/i, '').replace(/[<>:"/\\|?*]/g, '-'); }
function safeName(name) { return String(name).replace(/[<>:"/\\|?*]/g, '-'); }
function formatBytes(bytes) { return `${(bytes / 1024).toFixed(1)} KB`; }
function truncate(text) { return text.length > 160 ? `${text.slice(0, 157)}…` : (text || '[no selectable text]'); }
function addRecent(name, size) {
  const entries = JSON.parse(localStorage.getItem('pdf-studio-recents') ?? '[]').filter((item) => item.name !== name);
  entries.unshift({ name, size, opened: new Date().toISOString() });
  localStorage.setItem('pdf-studio-recents', JSON.stringify(entries.slice(0, 6)));
  renderRecents();
}
function renderRecents() {
  const target = $('#recent-area');
  if (!target) return;
  const entries = JSON.parse(localStorage.getItem('pdf-studio-recents') ?? '[]');
  target.innerHTML = entries.length ? `<div class="recent-heading">RECENT ON THIS DEVICE</div>${entries.map((item) => `<div class="recent-item"><span class="recent-file">▤</span><span><b>${escapeHtml(item.name)}</b><small>${formatBytes(item.size)} · history only; files are not retained</small></span></div>`).join('')}` : '';
}
function escapeHtml(text) { return String(text).replace(/[&<>"']/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char]); }
function clearWorkspace() {
  if (state.document && !window.confirm('Clear this PDF from the workspace? Unsaved edits will be discarded.')) return;
  state.name = ''; state.bytes = null; state.document = null; state.renderDocument = null; state.page = 1; state.selected.clear(); state.undo = []; state.redo = [];
  $('#doc-name').textContent = 'No document open'; $('#welcome').hidden = false; $('#page-wrap').hidden = true; $('#page-input').disabled = true; $('#page-total').textContent = 'of —';
  $('#thumb-list').replaceChildren(); $('#thumb-count').textContent = '0'; $('#status-page').textContent = 'No document'; setStatus('Open a PDF to get started'); $('#tool-panel').hidden = true; updateHistoryButtons();
}

renderShell();
