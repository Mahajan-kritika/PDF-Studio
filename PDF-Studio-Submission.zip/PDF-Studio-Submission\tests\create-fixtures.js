import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { PDFDocument, StandardFonts, rgb } from '@cantoo/pdf-lib';

const outputDirectory = join(process.cwd(), 'test-fixtures');
await mkdir(outputDirectory, { recursive: true });

async function save(name, document) {
  await writeFile(join(outputDirectory, name), await document.save());
}

async function textPdf(pageCount, name) {
  const document = await PDFDocument.create();
  const font = await document.embedFont(StandardFonts.Helvetica);
  for (let index = 1; index <= pageCount; index += 1) {
    const page = document.addPage([612, 792]);
    page.drawText(`PDF Studio test document - PAGE ${index}`, {
      x: 54, y: 720, size: 18, font, color: rgb(0.08, 0.18, 0.2),
    });
    page.drawText('Selectable sample text for local processing tests.', {
      x: 54, y: 688, size: 11, font,
    });
  }
  await save(name, document);
}

await textPdf(1, 'one-page.pdf');
await textPdf(10, 'ten-page.pdf');
await textPdf(50, 'fifty-page.pdf');
await textPdf(1, 'selectable-text.pdf');

const imageBytes = await readFile(join(outputDirectory, 'scanned-quality.png'));
await writeFile(join(outputDirectory, 'scanned-page.png'), imageBytes);
const imageDocument = await PDFDocument.create();
const image = await imageDocument.embedPng(imageBytes);
const imagePage = imageDocument.addPage([612, 792]);
imagePage.drawImage(image, { x: 80, y: 350, width: 452, height: 90 });
await save('scanned.pdf', imageDocument);
await save('image-content.pdf', imageDocument);

const forms = await PDFDocument.create();
const formPage = forms.addPage([612, 792]);
const form = forms.getForm();
form.createTextField('customer.name').addToPage(formPage, { x: 60, y: 650, width: 250, height: 26 });
form.createCheckBox('customer.approved').addToPage(formPage, { x: 60, y: 600, width: 18, height: 18 });
await save('form-fields.pdf', forms);

const protectedDocument = await PDFDocument.create();
protectedDocument.addPage([612, 792]).drawText('Password protected test PDF');
protectedDocument.encrypt({ userPassword: 'studio-test', ownerPassword: 'studio-owner' });
await save('password-protected.pdf', protectedDocument);

console.log(`Created test PDFs in ${outputDirectory}`);
