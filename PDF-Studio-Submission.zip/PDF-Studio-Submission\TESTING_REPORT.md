# PDF Studio testing report

## Environment

- Windows
- Node.js 24.18.1
- Vite local preview at `http://127.0.0.1:5173`
- Synthetic documents generated in `test-fixtures/`; no user PDFs used as test inputs

## Automated results

| Check | Result |
|---|---|
| Page range parsing and bounds validation | Passed |
| Complete page order validation | Passed |
| Merge and extract output structure/order | Passed |
| One-, ten-, and fifty-page fixture generation and reopen | Passed |
| Scanned image and AcroForm fixture structure | Passed |
| Open encrypted fixture with password | Passed |
| Encrypt a PDF and reopen with password | Passed |
| Reorder, duplicate, rotate, crop, and delete pages | Passed |
| Add text and image; update and clear standard metadata | Passed |
| Redaction: PDF.js confirms original text is not selectable in the output | Passed |
| Total automated tests | **11 passed** |

Commands:

```powershell
npm.cmd test
npm.cmd run build
npm.cmd audit
```

The production build succeeds. Vite reports a large JavaScript chunk (approximately 994 KB minified, approximately 374 KB gzip); this is a size warning, not a build failure. `npm audit` reports zero known vulnerabilities.

## Browser checks

- Opened the generated scanned PDF in the app and viewed its rendered preview.
- Ran the bundled local OCR against the scanned fixture; recognized `SCANNED PDF`.
- Filled the AcroForm name and checkbox fields in the UI; the app confirmed the values were saved.
- Switched from a one-page scanned document to the ten-page document; the page renderer completed without errors after render-task cancellation was added.
- Observed 26 app requests in a local browser trace; none were external HTTP(S) requests. A `blob:` URL was used for local PDF processing.
- Captured an editor screenshot at `screenshots/pdf-studio-editor.png`. The earlier home screenshot contained a locally stored recent-document filename and is intentionally not included in this submission.

## Not verified

- Wi-Fi-disabled operation was not manually tested. Runtime assets are bundled locally and browser tracing observed no external HTTP(S) requests, but full offline operation is not certified.
- Exported PDFs were not opened in a separate desktop PDF reader.
- All 29 operations were not individually exercised through the UI. Automated coverage is focused on representative structural operations and security-sensitive redaction; manually inspect important output documents before use.
- OCR returns text for download; it does not add a searchable text layer to a PDF. OCR accuracy varies with image quality.
