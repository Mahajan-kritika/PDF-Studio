import { describe, expect, it } from 'vitest';
import { degrees, PDFDocument } from '@cantoo/pdf-lib';
import { readFile } from 'node:fs/promises';
import { join } from 'node:path';
import * as pdfjs from 'pdfjs-dist/legacy/build/pdf.mjs';
import {
  addImage, addText, clearStandardMetadata, encryptPdf, extractPdf, makeMergedPdf, makePdf,
  parsePageOrder, parsePageRanges, rasterRedact,
} from '../src/pdf-tools.js';

describe('page selection helpers', () => {
  it('parses and de-duplicates page ranges in ascending order', () => {
    expect(parsePageRanges('5, 1-3, 3', 5)).toEqual([0, 1, 2, 4]);
  });

  it('rejects invalid and out-of-bounds ranges', () => {
    expect(() => parsePageRanges('1-6', 5)).toThrow(/outside/);
    expect(() => parsePageRanges('a', 5)).toThrow(/Invalid/);
  });

  it('requires a complete page order without duplicates', () => {
    expect(parsePageOrder('3,1,2', 3)).toEqual([2, 0, 1]);
    expect(() => parsePageOrder('1,1,3', 3)).toThrow(/exactly once/);
    expect(() => parsePageOrder('1,2', 3)).toThrow(/all 3/);
  });
});

describe('PDF operations', () => {
  it('merges files and extracts selected pages into valid PDFs', async () => {
    const first = await PDFDocument.create();
    first.addPage([200, 300]);
    first.addPage([210, 310]);
    const second = await PDFDocument.create();
    second.addPage([220, 320]);
    const files = [
      new File([await first.save()], 'first.pdf', { type: 'application/pdf' }),
      new File([await second.save()], 'second.pdf', { type: 'application/pdf' }),
    ];
    const merged = await makeMergedPdf(files);
    const mergedDoc = await PDFDocument.load(merged);
    expect(mergedDoc.getPageCount()).toBe(3);

    const extracted = await extractPdf(mergedDoc, [2, 0]);
    const extractedDoc = await PDFDocument.load(extracted);
    expect(extractedDoc.getPageCount()).toBe(2);
    expect(extractedDoc.getPage(0).getWidth()).toBe(220);
    expect(extractedDoc.getPage(1).getWidth()).toBe(200);
  });

  it('creates and reopens one-, ten-, and fifty-page samples', async () => {
    for (const [fileName, pageCount] of [['one-page.pdf', 1], ['ten-page.pdf', 10], ['fifty-page.pdf', 50]]) {
      const bytes = await readFile(join(process.cwd(), 'test-fixtures', fileName));
      const document = await PDFDocument.load(bytes);
      expect(document.getPageCount()).toBe(pageCount);
    }
  });

  it('creates a page containing an image-only scan and interactive form fields', async () => {
    const scanned = await PDFDocument.load(await readFile(join(process.cwd(), 'test-fixtures', 'scanned.pdf')));
    expect(scanned.getPageCount()).toBe(1);
    expect(scanned.getPage(0).node.Contents()).not.toBeNull();
    const formDocument = await PDFDocument.load(await readFile(join(process.cwd(), 'test-fixtures', 'form-fields.pdf')));
    expect(formDocument.getForm().getFields().map((field) => field.getName())).toEqual(['customer.name', 'customer.approved']);
  });

  it('opens the locally generated password-protected sample with its password', async () => {
    const bytes = await readFile(join(process.cwd(), 'test-fixtures', 'password-protected.pdf'));
    await expect(PDFDocument.load(bytes)).rejects.toThrow();
    const unlocked = await PDFDocument.load(bytes, { password: 'studio-test' });
    expect(unlocked.getPageCount()).toBe(1);
  });

  it('encrypts edited PDF bytes and verifies the user password', async () => {
    const source = await PDFDocument.create();
    source.addPage([200, 300]);
    const encryptedBytes = await encryptPdf(await source.save(), 'local-test', 'owner-test');
    await expect(PDFDocument.load(encryptedBytes)).rejects.toThrow();
    expect((await makePdf(encryptedBytes, 'local-test')).getPageCount()).toBe(1);
  });

  it('reorders, duplicates, rotates, crops, and deletes real pages', async () => {
    const source = await PDFDocument.create();
    source.addPage([200, 300]);
    source.addPage([210, 310]);
    source.addPage([220, 320]);

    const reordered = await PDFDocument.create();
    const pages = await reordered.copyPages(source, [2, 0, 1]);
    pages.forEach((page) => reordered.addPage(page));
    expect(reordered.getPages().map((page) => page.getWidth())).toEqual([220, 200, 210]);

    reordered.getPage(0).setRotation(degrees(90));
    reordered.getPage(0).setCropBox(10, 10, 180, 280);
    const [duplicate] = await reordered.copyPages(reordered, [0]);
    reordered.insertPage(1, duplicate);
    expect(reordered.getPageCount()).toBe(4);
    expect(reordered.getPage(0).getRotation().angle).toBe(90);
    expect(reordered.getPage(0).getCropBox().width).toBe(180);
    reordered.removePage(1);
    expect(reordered.getPageCount()).toBe(3);
    expect(reordered.getPage(1).getWidth()).toBe(200);
  });

  it('adds editable text and an image, then updates document metadata', async () => {
    const source = await PDFDocument.create();
    source.addPage([612, 792]);
    const textBytes = await addText(source, 0, 'Added by PDF Studio', {
      x: 30, y: 120, size: 14, color: '#19363c',
    });
    const document = await PDFDocument.load(textBytes);
    const png = await readFile(join(process.cwd(), 'test-fixtures', 'scanned-page.png'));
    const imageBytes = await addImage(document, 0, png, 'image/png', { x: 20, y: 20, width: 100, height: 25 });
    const updated = await makePdf(imageBytes);
    updated.setTitle('Local sample');
    updated.setAuthor('PDF Studio test');
    expect(updated.getTitle()).toBe('Local sample');
    expect(updated.getAuthor()).toBe('PDF Studio test');
    clearStandardMetadata(updated);
    const cleared = await makePdf(await updated.save());
    expect(cleared.getTitle()).toBe('');
    expect(cleared.getAuthor()).toBe('');
    expect(cleared.getCreator()).toBe('');
    expect(cleared.getProducer()).toBe('');
    expect(cleared.getCreationDate()?.getTime()).toBe(0);
    expect(updated.getPageCount()).toBe(1);
    expect(updated.getPage(0).node.Contents()).not.toBeNull();
  });

  it('builds a redacted PDF without copying the redacted page objects', async () => {
    const source = await PDFDocument.create();
    const page = source.addPage([300, 400]);
    page.drawText('SECRET-CONTENT-TO-REMOVE', { x: 10, y: 200, size: 10 });
    const sourceBytes = await source.save();
    const pngBytes = await readFile(join(process.cwd(), 'test-fixtures', 'scanned-page.png'));
    const redactedBytes = await rasterRedact(source, 0, pngBytes);
    const originalPdf = await pdfjs.getDocument({ data: sourceBytes }).promise;
    const redactedPdf = await pdfjs.getDocument({ data: redactedBytes }).promise;
    const originalText = await (await originalPdf.getPage(1)).getTextContent();
    const redactedText = await (await redactedPdf.getPage(1)).getTextContent();
    expect(originalText.items.map((item) => item.str).join(' ')).toContain('SECRET-CONTENT-TO-REMOVE');
    expect(redactedText.items.map((item) => item.str).join(' ')).toBe('');
  });
});
